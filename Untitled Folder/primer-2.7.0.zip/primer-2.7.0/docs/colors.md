---
layout: page
title: Colors
---

The look and feel of our company and product relies on using a handful of specific colors that help convey meaning and purpose.

### Branding

<div class="swatch swatch-blue"></div>
<div class="swatch swatch-green"></div>
<div class="swatch swatch-red"></div>
<div class="swatch swatch-orange"></div>
<div class="swatch swatch-purple"></div>

### Grayscale

<div class="swatch swatch-gray-light"></div>
<div class="swatch swatch-gray"></div>
<div class="swatch swatch-gray-dark"></div>
